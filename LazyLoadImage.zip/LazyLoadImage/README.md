# LazyLoadImage

This is a demo which delays loading webview-image using jquery.lazyload.js .

For more information , plsese enter here : http://www.jianshu.com/p/06f0034b6997
