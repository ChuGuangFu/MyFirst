//
//  ViewController.m
//  LazyloadImage
//
//  Created by 梁羽 on 16/11/30.
//  Copyright © 2016年 梁羽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

